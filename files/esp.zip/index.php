<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>esp</title>
</head>
<body>
<p>Получаем данные с ЕСП</p>
<?php
if (isset($_REQUEST['nam']) ) {  // проверяем есть ли что в для получения
file_put_contents('1.txt', $_REQUEST['nam'].'<br>', FILE_APPEND);  // дописываем данные из супер переменной в файл 1.txt
}
echo(file_get_contents('1.txt'));   // выводим все из файла
?>

</body>
</html>



